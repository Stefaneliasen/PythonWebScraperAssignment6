import requests
from bs4 import BeautifulSoup
import networkx as nx

DG = nx.DiGraph()

def scrape_to_list(url):
    empty_list = []
    r = requests.get(url)
    data = r.text
    soup = BeautifulSoup(data, "html.parser")
    all_a = soup.find_all('a')
    for a in all_a:
        if 'href' in a.attrs:
            href = a.attrs['href']
            if 'http://' in href and href not in empty_list:
                empty_list.append(href)
    return empty_list

def grab_graph_data(link_to_website_entry, end_depth):

    if end_depth > 2:
        print("WARNING. DO NOT GO OVER 2 IN RECURSIONS!")

    else:
        array_of_hrefs = scrape_to_list(link_to_website_entry)

        recursive(link_to_website_entry, array_of_hrefs, 0, end_depth, True)
    
    return DG



def recursive(link_to_website_entry, array_of_hrefs, counter, end_depth, start):
    # Initializer
    if start == True:
        for x in range(0, len(array_of_hrefs)):
            DG.add_edge(link_to_website_entry, array_of_hrefs[x])
        start = False
        recursive(link_to_website_entry, array_of_hrefs, counter, end_depth, start)
    elif end_depth == counter:
        return
    else: 
        for name in array_of_hrefs:
            name_of_link = name
            container = scrape_to_list(name_of_link)
            for x in range(0, len(container)):
                DG.add_edge(name_of_link, container[x])
            recursive(link_to_website_entry, container, counter + 1, end_depth, start)