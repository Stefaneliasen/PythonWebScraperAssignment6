import requests
from bs4 import BeautifulSoup
import time
import networkx as nx
import matplotlib.pyplot as plt
from lib import grab_graph_data

if __name__ == '__main__':

    start = time.time()

    # Draw

    # It works dynamically in terms of nodes, but do not try with over 2. It eats your cpu by ALOT.

    DG = grab_graph_data("http://www.pyregex.com/", 1)

    nx.draw(DG, with_labels=True, font_weight='bold')

    print(f'It took {time.time() - start}s in total.')

    plt.show()

